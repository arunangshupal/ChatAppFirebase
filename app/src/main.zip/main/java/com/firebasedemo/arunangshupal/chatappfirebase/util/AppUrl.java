package com.firebasedemo.arunangshupal.chatappfirebase.util;

/**
 * Created by Arunangshu Pal on 5/14/2016.
 */
public class AppUrl {

    public static final String FIREBASE_URL="https://chatappfirebasearu.firebaseio.com/";
    public static final String USER="User";
    public static final String MESSAGE_INBOX="msgBox";

}
