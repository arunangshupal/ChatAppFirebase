package com.firebasedemo.arunangshupal.chatappfirebase.util;

/**
 * Created by Arunangshu Pal on 5/14/2016.
 */
public class AppConstant {
    public static final  String SHARED_PREF_KEY="myPref";
    public static final  String USER_DETAILS_KEY="userDetails";
    public static final  String CONTACT_BEAN_KEY="contact";
    
}
